# Gate × Bybit Arbitrage Scanner

Static HTML MVP. No exchange API keys are required.

## Publish with GitHub Pages
1. Create a public GitHub repository named `arb-scanner`.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will be `https://YOUR-USERNAME.github.io/arb-scanner/`.

## Important limitations
- This version requests public Gate and Bybit spot ticker endpoints directly from the browser.
- Browser CORS/network restrictions may prevent those requests. GitHub Pages hosting does not bypass CORS.
- The current comparison is same-asset cross-exchange only, not multi-coin routes.
- It uses best bid/ask ticker fields, not order-book depth; results are indicative, not executable profit.
- Transfer/network fees and deposit/withdrawal status are not yet verified.
- Do not use results for live trades until order-book depth, fees, transfer routes, and execution timing are implemented and tested.
